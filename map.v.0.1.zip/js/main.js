/*
 * Application entry point
 */
$(window).load(function() {
    SM.App = new SM.AppController().init();
});
