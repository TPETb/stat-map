/*
 * Test Application name space
 */
if (!SM) {
    var SM = {};
}

/*
 * type: Controller class
 */
SM.AppController = function () {
    this._View = null; // SM.ApplicationView instance
    this._Model = null; // SM.Model instance
};

var appCtrlP = SM.AppController.prototype;

appCtrlP.init = function (config) {
    this._View = new SM.AppView().init();

    this._addEventListeners();

    return this;
};

appCtrlP._addEventListeners = function () {
};

appCtrlP = null;