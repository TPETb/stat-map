/*
 * Test Application name space
 */
if (!SM) {
    var SM = {};
}

/*
 * type: View class
 */
SM.AppView = function() {
    this.map = {}; // Map container
    this.config = {}; // Configuration
};

var appViewP = SM.AppView.prototype;

appViewP.init = function(config) {
    this.map.container = $('#map');

    this.resizeMap($(window).width(), $(window).height());
    this._renderMap();

    this._addEventListeners();

    return this;
};


appViewP._addEventListeners = function() {
    $(window).on('resize', $.proxy(this._onViewportResize, this));
};


appViewP._renderMap = function() {
    this.map.map = L.map(this.map.container.attr('id')).setView([39, 58.5], 6);
    L.tileLayer('http://{s}.tile.cloudmade.com/d4fc77ea4a63471cab2423e66626cbb6/997/256/{z}/{x}/{y}.png', {
        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
        maxZoom: 18
    }).addTo(this.map.map);
};

appViewP._syncMap = function() {

};

appViewP._calculateZoomRange = function() {

};

appViewP._onViewportResize = function() {
    this.resizeMap($(window).width(), $(window).height());
};

appViewP.resizeMap = function(width, height) {
    this.map.container.width(width).height(height);
};

appViewP._onResize = function() {
    this._calculateZoomRange();
};

appViewP = null;



/*
 * Turkmenistan bounding box
json = {
    "southWest": {
        "latitude": "35.141090",
        "longitude": "52.441429"
    },
    "northEast": {
        "latitude": "42.795551",
        "longitude": "66.684303"
    }
};

52.441429 35.141090 66.684303 42.795551 - map tiler formatted
*/